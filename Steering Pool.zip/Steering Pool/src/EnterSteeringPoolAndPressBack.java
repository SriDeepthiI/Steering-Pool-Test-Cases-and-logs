import java.time.Duration;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
public class EnterSteeringPoolAndPressBack {
    public static void main(String[] args) throws InterruptedException {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\admin\\Downloads\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
        RealM rm = new RealM();
        Steering_Pool sp = new Steering_Pool();
        try {
            sp.signIN(driver);
            sp.configuration(driver);
            boolean addRealM = rm.addRealM(driver, "realm1", 80, 30);
            assert addRealM;
            boolean pressBackPool = sp.enterSteeringPoolAndPressBack(driver, "20.0.0.0", "realm1");
            assert pressBackPool;
        }
        catch (InterruptedException e) {
            System.out.println(e);
        }
        finally {
            sp.cleanUp(driver);
            rm.cleanUp(driver);
            sp.logOut(driver);
        }
    }
}

