import java.time.Duration;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
public class AddMultipleDeleteFewSteeringPool {
    public static void main(String[] args) throws InterruptedException {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\admin\\Downloads\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
        RealM rm = new RealM();
        Steering_Pool sp = new Steering_Pool();
        try {
            sp.signIN(driver);
            sp.configuration(driver);
            boolean addRealM = rm.addRealM(driver, "realm1", 80, 30);
            assert addRealM;
            String[] IPs = {"192.168.1.1", "192.168.1.2", "192.168.1.3"};
            boolean addMultiple = sp.addMultipleSteeringPool(driver, IPs, "realm1");
            assert addMultiple;
            String[] iPs = {"192.168.1.1", "192.168.1.2"};
            boolean deleteFew = sp.deleteSelective(driver, iPs, "realm1");
            assert deleteFew;
        }
        catch (InterruptedException e) {
            System.out.println(e);
        }
        finally {
            sp.cleanUp(driver);
            rm.cleanUp(driver);
            sp.logOut(driver);
        }
    }
}

